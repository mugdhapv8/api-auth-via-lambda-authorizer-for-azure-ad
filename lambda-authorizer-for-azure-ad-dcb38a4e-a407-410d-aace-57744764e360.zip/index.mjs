import jwt_decode from "jwt-decode";

  const defaultDenyAllPolicy = {
    "principalId":"user",
    "policyDocument":{
      "Version":"2012-10-17",
      "Statement":[
        {
          "Action":"execute-api:Invoke",
          "Effect":"Deny",
          "Resource":"*"
        }
      ]
    }
  };
  
  const iamPolicytoInvokeAPI = {
    "Version": "2012-10-17",
    "Statement": [
      {
        "Sid": "Stmt1686153513901",
        "Action": "execute-api:Invoke",
        "Effect": "Allow",
        "Resource": "arn:aws:execute-api:us-east-1:754882678188:bverol6e70/*/*"
      }
    ]
  };

  async function jwt_decode_func(token) {
    console.log("decode jwt access token function");
    // decode the jwt token
    const result = jwt_decode(token);
    if(result == null){
      console.log("jwt decode function failed");
      return null;
    }
    else{
        console.log("jwt decode function successful");
        return result; 
    }
  };

  async function verify_access_token(decodedToken) {
    // verify the decoded jwt token
    console.log("verify access token function");
    //define azure AD creds. change this to match your Azure AD configuration
    const clientId = 'ec1beabd-e090-4ec4-af82-e65fa8152a45';
    const issuer = 'https://sts.windows.net/ec1beabd-e090-4ec4-af82-e65fa8152a45/';
    const audience = 'api://00a37a3b-319e-43de-8213-5f2179aea173';
    //get token creds from decoded token
    const decodedClientId = decodedToken.tid;
    const decodedIssuer = decodedToken.iss;
    const decodedAudience = decodedToken.aud;
    const decodedScope = decodedToken.scp;
    
    if((clientId == decodedClientId) && (issuer == decodedIssuer) && (audience == decodedAudience)) {
      console.log('token verified');
      return decodedScope;
    }else {
      console.log("token verification failed");
      return null;
    }
  };
  
export const handler = async(event) => {
    let iamPolicy = null;
    
    console.log(event);
    if (event == null)
      {
        console.log('no event found');
        iamPolicy = defaultDenyAllPolicy;
      }
    else {
      const token = event.headers.authorization.replace("Bearer", "");
      const decodedToken = await jwt_decode_func(token);
      const scopeClaims =  await verify_access_token(decodedToken);
      console.log(scopeClaims);
    
      let response = null;
      
      if (scopeClaims === null) {
          response = {
              "isAuthorized": false
              // "policyDocument": defaultDenyAllPolicy
          };
      }
      else{
          response = {
            // "policyDocument": iamPolicytoInvokeAPI
              "isAuthorized": true
          };
      }
    return response;
    }
};

